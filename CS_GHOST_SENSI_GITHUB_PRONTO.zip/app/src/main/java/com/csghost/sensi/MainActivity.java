package com.csghost.sensi;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.view.View;
import android.graphics.Color;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(3,6,3)); getWindow().setNavigationBarColor(Color.BLACK);
 WebView w=new WebView(this); w.setBackgroundColor(Color.rgb(3,6,3)); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); w.setOverScrollMode(View.OVER_SCROLL_NEVER); setContentView(w); w.loadUrl("file:///android_asset/index.html"); }
 @Override public void onBackPressed(){setContentView(getWindow().getDecorView()); super.onBackPressed();}
}